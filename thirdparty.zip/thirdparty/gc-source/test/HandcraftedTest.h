#pragma once

class HandcraftedTest
{
public:
	static void Test() ;
};
