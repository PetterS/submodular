#pragma once

extern float PRGC_CAP_INFINITY;
extern int PRGC_RELABEL_ALL_AFTER_EVERY;
extern int PRGC_MAX_DIST_LABEL;

#include "prgc/PRGCDataStructures.h"
