// stdafx.cpp : source file that includes just the standard includes
// SubmodularNC2L.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information
#include "stdafx.h"

int BLUR_KERNEL_MIN_X, BLUR_KERNEL_MIN_Y, BLUR_KERNEL_MAX_X, BLUR_KERNEL_MAX_Y;
std::vector<CvPoint> BLUR_KERNEL;
std::vector<double> BLUR_KERNEL_WEIGHTS;
int CLIQUE_WIDTH;
int CLIQUE_HEIGHT;
int CLIQUE_SIZE;
int IMG_WIDTH;
int IMG_HEIGHT;

