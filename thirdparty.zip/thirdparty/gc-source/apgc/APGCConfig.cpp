#include "StdAfx.h"
#include "APGCConfig.h"

std::list<std::pair<APGCAuxNode*, int> > TIGHT_CONSTRAINTS;
int _maxSrcDist, _maxSinkDist;
