#include "stdafx.h"

#include "test/HandcraftedTest.h"

int main(int argc, char* argv[])
{
	HandcraftedTest::Test();
	return 0;
}