#include "StdAfx.h"
#include "PRGCConfig.h"

float PRGC_CAP_INFINITY = 10000;
int PRGC_RELABEL_ALL_AFTER_EVERY = 1000;
int PRGC_MAX_DIST_LABEL;
